# dashboard/views.py
from django.shortcuts import render

def dashboard(request):
    return render(request, 'dashboard.html')

def customer_dashboard(request):
    return render(request, 'dashboard/customer_dashboard.html')

