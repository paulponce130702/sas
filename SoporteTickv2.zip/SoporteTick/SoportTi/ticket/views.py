import random
import string
from django.db import IntegrityError
from django.shortcuts import render, redirect
from django.contrib import messages
from .form import CreateTicketForm, AssignTicketForm
from .models import Ticket

def create_ticket(request):
    if request.method == 'POST':
        form = CreateTicketForm(request.POST)
        if form.is_valid():
            var= form.save(commit=False)
            var.customer = request.user
            while not var.ticket_id:
                id = ''.join(random.choices(string.digits, k=6))
                try:
                    var.ticket_id = id
                    var.save()
                except IntegrityError:
                    continue
            messages.success(request, 'your ticket has been submited, A Support engineer would reach aut soon.')
            return redirect('customer_tickets')
        else:
            messages.warning(request, 'Somethin went wrong .Please check form erros ')
            return redirect('create_ticket')
    else:
        form = CreateTicketForm()
        context = {'form': form}
        return render(request, 'ticket/create_ticket.html', context)

def customer_tickets(request):
    tickets = Ticket.objects.filter(customer=request.user).order_by('-created_on')
    context = {'tickets': tickets}
    return render(request, 'ticket/customer_tickets.html', context)

#assing ticket to engineers
def assign_ticket(request, ticket_id):
    ticket = Ticket.object.get(ticket_id=ticket_id)
    if  request.method == 'POST':
        form = AssignTicketForm(request.POST, instance=ticket)
        if form.is_valid():
            var = form.save(commit=False)
            var.is_assigned_to_engineer = True
            var.save()
            messages.success(request, f'ticket has been assigned to {var.engineer}')
            return redirect('ticket-queue')
        else:
            messages.warning(request, 'Something  went wrong .Please check form input ')
            return redirect('assign-ticket')
    else:
        form = AssignTicketForm()
        context = {'form':form}
        return render(request, 'ticket/assign_ticket.html', context)

#ticket details
def ticket_details(request, ticket_id):
    ticket = Ticket.object.get(ticket_id, ticket_id)
    context = {'ticket': ticket}
    return render(request, 'ticket/ticket_details.html', context)
#ticket queue(for only admins)
def ticket_queue(request):
    tickets = Ticket.object.filter(is_assigned_to_engineer=False)
    context = {'tickets': tickets}
    return render(request, 'ticket/ticket_queue.html', context)






